﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Domain.GameItem
{
    public class Item
    {
        ///TODO
    }
}
