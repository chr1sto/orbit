﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Game.Core.Data
{
    class RankingDbContext
    {
    }
}
