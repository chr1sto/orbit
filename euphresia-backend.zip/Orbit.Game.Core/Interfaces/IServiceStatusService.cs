﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Game.Core.Interfaces
{
    public interface IServiceStatusService
    {
        void Update();
    }
}
