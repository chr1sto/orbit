﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Infra.CrossCutting.Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
