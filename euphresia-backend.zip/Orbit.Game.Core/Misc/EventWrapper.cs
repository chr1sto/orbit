﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Game.Core.Misc
{
    internal class EventWrapper
    {
        public string MessageType { get; set; }
    }
}
