﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orbit.Game.Core.Misc
{
    public class MonitorProcessInfo
    {
        public string ProcessName { get; set; }
        public string ServiceName { get; set; }
    }
}
